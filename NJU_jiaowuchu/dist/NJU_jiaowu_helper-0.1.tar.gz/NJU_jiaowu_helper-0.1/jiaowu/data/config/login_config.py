login_headers = {
        'Referer': "http://elite.nju.edu.cn/jiaowu/",
        'Cache-Control': "max-age=0",
        'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        'Accept-Language': "zh-CN",
        'Content-Type': "application/x-www-form-urlencoded",
        'Upgrade-Insecure-Requests': "1",
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362",
        'Accept-Encoding': "gzip, deflate",
        'Host': "elite.nju.edu.cn",
        'Connection': "keep-alive"
    }