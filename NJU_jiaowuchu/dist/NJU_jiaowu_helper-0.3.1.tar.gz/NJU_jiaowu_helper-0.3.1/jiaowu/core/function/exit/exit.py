import sys

from jiaowu.core.model.spider_model import LoginSpider


def terminate(spider:LoginSpider,args):
    sys.exit()