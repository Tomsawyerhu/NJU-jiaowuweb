"""
项目路径配置
"""
CONFIG_ROOT_PATH="" #配置根路径
DIARY_PATH="" #日志路径 file:log.txt
LOGIN_CONFIG_PATH="" #登录请求头配置路径 file:login_config.py
TASK_CONFIG_PATH=""  #任务请求头配置路径 file:task_config.json
...