"""
日志信息
"""


class ActionMsg:
    # 操作信息
    DOWNLOAD_TIMETABLE = "下载课程表"
    APPLY_FOR_EXAM_ONLY = "申请免修不免考"
    CANCEL_EXAM_ONLY = "取消免修不免考申请"


status_msg = {
    # 状态信息
    'Success', "Failure"
}
